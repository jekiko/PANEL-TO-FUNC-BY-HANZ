from flask import Flask, render_template, request, redirect, url_for
import sqlite3
import os

app = Flask(__name__)
app.secret_key = 'edukasi_cyber_sekolah_2023'

# Inisialisasi database
def init_db():
    conn = sqlite3.connect('database/users.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS users
                 (id INTEGER PRIMARY KEY, username TEXT, password TEXT)''')
    # Data dummy untuk simulasi
    dummy_users = [
        ('admin', 'admin123'),
        ('guru', 'passwordguru'),
        ('siswa', 'murid2023')
    ]
    c.executemany("INSERT OR IGNORE INTO users (username, password) VALUES (?, ?)", dummy_users)
    conn.commit()
    conn.close()

init_db()

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/sqli', methods=['GET', 'POST'])
def sqli():
    message = None
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']

        conn = sqlite3.connect('database/users.db')
        c = conn.cursor()

        query = f"SELECT * FROM users WHERE username='{username}' AND password='{password}'"
        c.execute(query)
        user = c.fetchone()

        conn.close()

        if user:
            message = f"Login berhasil! (User: {user[1]})"
        else:
            message = "Login gagal! Coba lagi"

    return render_template('sqli.html', message=message)

@app.route('/xss', methods=['GET', 'POST'])
def xss():
    comment = None
    if request.method == 'POST':
        comment = request.form['comment']
    return render_template('xss.html', comment=comment)

@app.route('/pathtraversal', methods=['GET', 'POST'])
def pathtraversal():
    content = None
    safe_mode = True

    if request.method == 'POST':
        filename = request.form['filename']
        base_dir = os.path.abspath('safe_files')

        if safe_mode:
            requested_path = os.path.abspath(os.path.join(base_dir, filename))
            if not requested_path.startswith(base_dir):
                content = "Akses ditolak: Path tidak valid!"
            else:
                try:
                    with open(requested_path, 'r') as f:
                        content = f.read()
                except Exception as e:
                    content = f"Error: {str(e)}"
        else:
            try:
                with open(filename, 'r') as f:
                    content = f.read()
            except Exception as e:
                content = f"Error: {str(e)}"

    return render_template('pathtraversal.html', content=content)

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=5000, debug=True)
